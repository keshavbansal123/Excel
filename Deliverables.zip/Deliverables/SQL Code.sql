WITH ShiftSessions AS (
    SELECT 
        ts.tutor_shift_id,
        ts.user_id,
        ts.shift_start,
        ts.shift_end,
        sc.service_session_start_time,
        sc.service_session_end_time
    FROM fact_tutor_shift_filtered ts
    INNER JOIN fact_service_channel sc
        ON ts.user_id = sc.service_user_id
        AND (
            sc.service_session_start_time BETWEEN ts.shift_start AND ts.shift_end
            OR sc.service_session_end_time BETWEEN ts.shift_start AND ts.shift_end
        )
),

OrderedSessions AS (
    SELECT 
        tutor_shift_id,
        user_id,
        shift_start,
        shift_end,
        service_session_start_time,
        service_session_end_time,
        LEAD(service_session_start_time) OVER (PARTITION BY tutor_shift_id 
		ORDER BY service_session_start_time) AS next_session_start_time
    FROM ShiftSessions
),

IdleGaps AS (
    SELECT
        tutor_shift_id,
        user_id,
        DATEDIFF(SECOND, service_session_end_time, next_session_start_time) AS gap_between_sessions_seconds
    FROM OrderedSessions
    WHERE next_session_start_time IS NOT NULL
          AND DATEDIFF(SECOND, service_session_end_time, next_session_start_time) > 0
),

SessionDurations AS (
    SELECT 
        ts.tutor_shift_id,
        ts.user_id,
        ts.shift_start,
        ts.shift_end,
        DATEDIFF(SECOND, ts.shift_start, ts.shift_end) AS shift_duration_seconds,
        SUM(DATEDIFF(SECOND, sc.service_session_start_time, sc.service_session_end_time)) AS total_session_seconds
    FROM fact_tutor_shift_filtered ts
    LEFT JOIN fact_service_channel sc
        ON ts.user_id = sc.service_user_id
        AND (
            sc.service_session_start_time BETWEEN ts.shift_start AND ts.shift_end
            OR sc.service_session_end_time BETWEEN ts.shift_start AND ts.shift_end
        )
    GROUP BY ts.tutor_shift_id, ts.user_id, ts.shift_start, ts.shift_end
),

IdleTimes AS (
    SELECT 
        tutor_shift_id,
        user_id,
        SUM(gap_between_sessions_seconds) AS actual_idle_time_between_sessions_seconds
    FROM IdleGaps
    GROUP BY tutor_shift_id, user_id
)

SELECT 
    sd.tutor_shift_id,
    sd.user_id,
    sd.shift_start,
    sd.shift_end,
    
    ROUND(sd.shift_duration_seconds / 60.0, 2) AS shift_duration_minutes,
    ROUND(ISNULL(sd.total_session_seconds, 0) / 60.0, 2) AS total_session_minutes,
    ROUND(ISNULL(it.actual_idle_time_between_sessions_seconds, 0) / 60.0, 2) AS idle_time_between_sessions_minutes,
    
    -- Difference (gap between total shift and (sessions + idle gaps))
    ROUND( (sd.shift_duration_seconds - ISNULL(sd.total_session_seconds, 0) - ISNULL(it.actual_idle_time_between_sessions_seconds, 0)) / 60.0, 2 ) AS difference_in_minutes,
    
    -- KPIs
    ROUND( ISNULL(sd.total_session_seconds, 0) * 100.0 / NULLIF(sd.shift_duration_seconds,0), 2) AS utilization_percentage,
	ROUND( (sd.shift_duration_seconds - ISNULL(sd.total_session_seconds, 0)) * 100.0 / NULLIF(sd.shift_duration_seconds,0), 2) AS non_utilization_percentage,
    ROUND( ISNULL(it.actual_idle_time_between_sessions_seconds, 0) * 100.0 / NULLIF(sd.shift_duration_seconds,0), 2) AS idle_percentage,
    ROUND( (sd.shift_duration_seconds - ISNULL(sd.total_session_seconds, 0) - ISNULL(it.actual_idle_time_between_sessions_seconds, 0)) * 100.0 / NULLIF(sd.shift_duration_seconds,0), 2) AS waste_percentage

FROM SessionDurations sd
LEFT JOIN IdleTimes it
    ON sd.tutor_shift_id = it.tutor_shift_id
ORDER BY sd.tutor_shift_id;
